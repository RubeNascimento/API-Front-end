<template>
  <div id="app">
    <responsiveNavigationBar
      :nav-links="navLinks"
      :image-path="require('./assets/calendar.png')"
      background="#1d1d1d"
    />
    <router-view />
  </div>
</template>
<script src="https://unpkg.com/ionicons@5.5.1/dist/ionicons.js"></script>
<script>
// import HelloWorld from './components/HelloWorld';
import responsiveNavigationBar from "@/components/responsiveNavigationBar";
export default {
  components: {
    responsiveNavigationBar,
  },
  data: () => ({
    navLinks: [
      {
        text: "About",
        path: "/About",
        icon: "ion-ios-help-circle",
      },
      {
        text: "Produto",
        path: "/Produto",
        icon: "ion-ios-navigate",
      },
      {
        text: "Produtos",
        path: "/Produtos",
        icon: "ion-ios-paper",
      },
      {
        text: "Login",
        path: "/Login",
        icon: "ion-ios-contact",
      },
    ],
  }),
};
</script>
<style lang="less">
html {
  font-family: "Ubuntu", sans-serif;
}
</style>
