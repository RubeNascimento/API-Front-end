<template>
  <div
    class="mx-auto overflow-hidden"
    height="100%"
    width="100%"
  >
    <v-system-bar color="deep-purple darken-3"></v-system-bar>

    <v-app-bar
      color="deep-purple accent-4"
      dark
      prominent dense
    >
      <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>

      <v-toolbar-title><!--Titulo--></v-toolbar-title>

      <v-spacer></v-spacer>

      <v-btn icon>
        <v-icon>mdi-magnify</v-icon>
      </v-btn>

      <v-btn icon>
        <v-icon>mdi-filter</v-icon>
      </v-btn>

      <v-btn icon>
        <v-icon>mdi-dots-vertical</v-icon>
      </v-btn>
    </v-app-bar>

    <v-navigation-drawer
      v-model="drawer"
      absolute
      bottom
      temporary
    >
      <v-list
        nav
        dense
      >
        <v-list-item-group
          v-model="group"
          active-class="deep-purple--text text--accent-4"
        >
          <router-link to="/About">
            <v-list-item>
              <v-list-item-title>About</v-list-item-title>
            </v-list-item>
          </router-link>

          <router-link to="/Produto">
            <v-list-item>
              <v-list-item-title>Produto</v-list-item-title>
            </v-list-item>
          </router-link>

          <router-link to="/Produtos">
            <v-list-item>
              <v-list-item-title>Produtos</v-list-item-title>
            </v-list-item>
          </router-link>

          <router-link to="/Login">
            <v-list-item>
              <v-list-item-title>Login</v-list-item-title>
            </v-list-item>
          </router-link>
        </v-list-item-group>
      </v-list>
    </v-navigation-drawer>
    <router-view></router-view>

  </div>
</template>
<script>

// import HelloWorld from './components/HelloWorld';

export default {
  data: () => ({
      drawer: false,
      group: null,
    }),

    watch: {
      group () {
        this.drawer = false
      },
    },
  name: 'App',

  // components: {
  //   HelloWorld,
  // },
};
</script>
