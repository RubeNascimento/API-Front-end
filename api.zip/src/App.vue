<template>
  <div id="app">
    <responsiveNavigationBar
      :nav-links="navLinks"
      :image-path="require('./assets/calendar.png')"
      background="#1d1d1d"
    />
    <router-view />
    <theFooter/>
  </div>
</template>
<script src="https://unpkg.com/ionicons@5.5.1/dist/ionicons.js"></script>
<script>
// import HelloWorld from './components/HelloWorld';
import responsiveNavigationBar from "@/components/responsiveNavigationBar";
import theFooter from "@/components/theFooter";
export default {
  components: {
    responsiveNavigationBar,
    theFooter
  },
  data: () => ({
    navLinks: [
      {
        text: "Home",
        path: "/",
        icon: "ion-ios-help-circle",
      },
      {
        text: "Regionais",
        path: "/FeriadosRegionais",
        icon: "ion-ios-navigate",
      },
      {
        text: "Internacionais",
        path: "/FeriadosInternacionais",
        icon: "ion-ios-flag",
      },
      {
        text: "Login",
        path: "/Login",
        icon: "ion-ios-contact",
      },
    ],
  }),
};
</script>
<style lang="less">
html {
  min-width: 1340px;
  font-family: "Ubuntu", sans-serif;
}
</style>
