import Vue from 'vue'
import App from './App.vue'
import router from './router'
import vuetify from './plugins/vuetify';
import firebase from "firebase";

Vue.config.productionTip = false



new Vue({
  router,
  vuetify,
  render: h => h(App)
}).$mount('#app')

const firebaseConfig = {
  apiKey: "AIzaSyACPAoKbrH2j_u2aARAUinNe2WAPoRuVKg",
  authDomain: "apilogin-fecc6.firebaseapp.com",
  projectId: "apilogin-fecc6",
  storageBucket: "apilogin-fecc6.appspot.com",
  messagingSenderId: "498386074508",
  appId: "1:498386074508:web:c2e3db0dc93a673f6b34a9"
};

firebase.initializeApp(firebaseConfig);
