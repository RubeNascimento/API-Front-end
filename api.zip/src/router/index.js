import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../views/Login.vue'
import Produtos from '../views/Produtos.vue'
import Regional from '../views/Regional.vue'
import Admin from '../views/Admin.vue'
import Erro from '../views/Erro.vue'

Vue.use(VueRouter)

const routes = [

  {
    path: '/Produtos',
    name: 'Produtos',
    component: Produtos
  },
  {
    path: '/Admin',
    name: 'Admin',
    component: Admin
  },
  {
    path: '/Regional',
    name: 'Regional',
    component: Regional,
    // meta: {
    //   requiresAuth: true,
    // }
  },
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  },
  {
    path: '/Login',
    name: 'Login',
    component: Login
  },
  {
    path: '*',
    name: 'Erro',
    component: Erro
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

// router.beforeEach((to, from, next) => {
//   const requiresAuth = to.matched.some(record => record.meta.requiresAuth);
//   if (requiresAuth) {
//     next('/Produto');
//   } 
//   else {
//     next('/Login');
//   }
// });

export default router
