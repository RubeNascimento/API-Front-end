import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../views/Login.vue'
import FeriadosInternacionais from '../views/FeriadosInternacionais.vue'
import FeriadosRegionais from '../views/FeriadosRegionais.vue'
import Admin from '../views/Admin.vue'
import Erro from '../views/Erro.vue'
import Home from '../views/Home.vue'

Vue.use(VueRouter)

const routes = [

  {
    path: '/FeriadosInternacionais',
    name: 'FeriadosInternacionais',
    component: FeriadosInternacionais
  },
  {
    path: '/Admin',
    name: 'Admin',
    component: Admin,
    meta: {
      requiresAuth: true,
    }
  },
  {
    path: '/FeriadosRegionais',
    name: 'FeriadosRegionais',
    component: FeriadosRegionais,
  },
  {
    path: '/Login',
    name: 'Login',
    component: Login
  },
  {
    path: '*',
    name: 'Erro',
    component: Erro
  },
  {
    path: '/',
    name: 'Home',
    component: Home
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

// router.beforeEach((to, from, next) => {
//   const requiresAuth = to.matched.some(record => record.meta.requiresAuth);
//   if (requiresAuth) {
//     next('/Admin');
//   } 
//   else {
//     next('/Login');
//   }
// });

export default router
