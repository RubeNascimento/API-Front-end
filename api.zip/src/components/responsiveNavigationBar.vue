<template>
  <nav :style="{ background: background || '#333' }">
    <h1>Calendar Events</h1>

    <ul :style="{ background: background || '#333' }" ref="nav">
      <figure @click="toggle_nav">
        <img class="image-logo" :src="imagePath" height="35px" width="35px" />
      </figure>
      <li
        v-for="(link, index) in navLinks"
        :key="index"
        @mouseenter="
          $event.currentTarget.style.background = hoverBackground || '#454545'
        "
        @mouseleave="
          $event.currentTarget.style.background = background || '#333'
        "
      >
        <router-link :to="link.path" :style="{ color: linkColor || '#DDD' }">
          {{ link.text }}
          <i :class="link.icon" />
        </router-link>
      </li>
    </ul>
  </nav>
</template>

<script>
export default {
  props: [
    "navLinks",
    "background",
    "linkColor",
    "hoverBackground",
    "imagePath",
  ],
  methods: {
    toggle_nav() {
      const nav = this.$refs.nav.classList;
      nav.contains("active") ? nav.remove("active") : nav.add("active");
    },
  },
};
</script>

<style scoped lang="scss">
@import "https://unpkg.com/ionicons@4.2.2/dist/css/ionicons.min.css";
nav {
  height: 60px;
  width: 100%;
  h1 {
    margin-top: 18px;
    margin-left: auto;
    margin-right: auto;
    left: 0;
    right: 0;
    text-align: center;
    position: absolute;
    font-size: 32px;
    font-family: "Zen Dots", sans-serif;
    color: #94c4ce;
  }
  ul {
    margin-block-start: 0;
    margin-block-end: 0;
    padding-inline-start: 0;
    display: flex;
    height: 100%;
    width: 300px;
    align-items: center;
    position: absolute;
    flex-direction: column;
    left: -240px;
    transition: 300ms ease all;
    padding-top: 60px;
    position: fixed;

    &.active {
      left: 0px;
    }

    figure {
      cursor: pointer;
      margin-left: 10px;
      margin-right: 10px;
      position: fixed;
      z-index: 1;
      top: 10px;
      left: 4px;
      &:hover {
        width: 40px;
        height: 40px;
      }
    }

    a {
      text-decoration: none;
      display: flex;
      flex-direction: row;
      align-items: center;
      margin-left: 20px;
      justify-content: space-between;
      margin-right: 10px;
    }

    i {
      margin-right: 10px;
      font-size: 22px;
    }

    li {
      list-style-type: none;
      padding: 10px 20px;
      padding-right: 0;
      padding-left: 0;
      width: 100%;
    }
  }
}
.image-logo:hover {
  width: 37px;
  height: 37px;
}
</style>
