<template>
  <nav :style="{ background: background || '#333' }">
    <h1>Feriados Regionais e Internacionais</h1>
    <!-- <div class="container"> -->
      <div class="app">
        <div class="app_calendar">
          <span class="weekday">{{semana}} </span>
          <div class="day">{{ dia}}</div>
        </div>
      </div>
    <!-- </div> -->

    <ul :style="{ background: background || '#333' }" ref="nav">
      <figure @click="toggle_nav">
        <img class="image-logo" :src="imagePath" height="35px" width="35px" />
      </figure>
      <li
        v-for="(link, index) in navLinks"
        :key="index"
        @mouseenter="
          $event.currentTarget.style.background = hoverBackground || '#454545'
        "
        @mouseleave="
          $event.currentTarget.style.background = background || '#333'
        "
      >
        <router-link :to="link.path" :style="{ color: linkColor || '#DDD' }">
          {{ link.text }}
          <i :class="link.icon" />
        </router-link>
      </li>
    </ul>
  </nav>
</template>

<script>
// var today = new Date();
// var week = today.getDate();
// var day = today.getDay();
// document.getElementById('dia').innerHTML=day;
// document.getElementById('week').innerHTML=week;  
var dateTime = new Date();
export default {
  
  data(){
    return {
      dia: '',
      semana: ''
    }
  },
  props: [
    "navLinks",
    "background",
    "linkColor",
    "hoverBackground",
    "imagePath",
  ],
  mounted(){

   this.dia = dateTime.getDate() + '/' + (dateTime.getMonth()+1);
      
      if(dateTime.getUTCDay() == 0){
        this.semana = "Domingo";
      }
      if(dateTime.getUTCDay() == 1){
        this.semana = "Segunda";
      }
      if(dateTime.getUTCDay() == 2){
        this.semana = "Terça";
      }
      if(dateTime.getUTCDay() == 3){
        this.semana = "Quarta";
      }
      if(dateTime.getUTCDay() == 4){
        this.semana = "Quinta";
      }
      if(dateTime.getUTCDay() == 5){
        this.semana = "Sexta";
      }
      if(dateTime.getUTCDay() == 6){
        this.semana = "Sábado";
      }

     // var dateTimeNewFormat = new Date().toJSON().slice(0,10).replace(/-/g,'/');
      //console.log(dateTimeNewFormat);
  },
  methods: {
    toggle_nav() {
      const nav = this.$refs.nav.classList;
      nav.contains("active") ? nav.remove("active") : nav.add("active");
    },
  },
 
};
</script>

<style scoped lang="scss">
@import "https://unpkg.com/ionicons@4.2.2/dist/css/ionicons.min.css";
nav {
  height: 60px;
  width: 100%;
  h1 {
    cursor: default;
    margin-top: 20px;
    margin-left: auto;
    margin-right: auto;
    left: 0;
    right: 0;
    text-align: center;
    position: absolute;
    font-size: 32px;
    font-family: "Zen Dots", sans-serif;
    color: #94c4ce;
  }
  ul {
    margin-block-start: 0;
    margin-block-end: 0;
    padding-inline-start: 0;
    display: flex;
    height: 100%;
    width: 210px;
    align-items: center;
    position: absolute;
    flex-direction: column;
    left: -150px;
    transition: 300ms ease all;
    padding-top: 60px;
    position: fixed;
    z-index: 1;

    &.active {
      left: 0px;
    }

    figure {
      cursor: pointer;
      margin-left: 10px;
      margin-right: 10px;
      position: fixed;
      z-index: 1;
      top: 10px;
      left: 4px;
      &:hover {
        width: 40px;
        height: 40px;
      }
    }

    a {
      text-decoration: none;
      display: flex;
      flex-direction: row;
      align-items: center;
      margin-left: 20px;
      justify-content: space-between;
      margin-right: 10px;
    }

    i {
      margin-right: 10px;
      font-size: 22px;
    }

    li {
      list-style-type: none;
      padding: 10px 20px;
      padding-right: 0;
      padding-left: 0;
      width: 100%;
    }
  }
}
.image-logo:hover {
  width: 37px;
  height: 37px;
}

/* app_calendar */

.app {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  cursor: default;
  margin-top: 5px;
  margin-left: auto;
  margin-right: 5px;
  left: 0;
  right: 0;
  text-align: center;
  position: absolute;
  font-family: "Ubuntu", sans-serif;
}
.app_calendar {
	width: 60px;
	height: 50px;
	border-radius: 6px;
	overflow: hidden;
  display: flex;
  flex-direction: column;
}
.app_calendar .weekday,
.app_calendar .day {
	display: flex;
	justify-content: center;
	align-items: center;
}
.app_calendar .weekday {
	position: relative;
	height: 56px;
	color: white;
	font-size: 12px;
	font-weight: 500;
	background-color: #d9383c;
}
.app_calendar .weekday:before,
.app_calendar .weekday:after {
	content: "";
	display: block;
	width: 10px;
	height: 10px;
	border-radius: 50%;
	position: absolute;
	top: calc(50% - 5px);
	box-shadow: rgba(255, 255, 255, 0.1) 0px 1px 1px 0px inset,
		rgba(50, 50, 93, 0.25) 0px 50px 100px -20px,
		rgba(0, 0, 0, 0.3) 0px 30px 60px -30px;
}
.app_calendar .weekday:before {
	left: 30px;
}
.app_calendar .weekday:after {
	right: 30px;
}
.app_calendar .day {
	height: 144px;
	color: black;
	font-size: 12px;
	font-weight: bold;
	background-color: snow;
}
/* app_name */
.app_name {
	color: black;
	font-size: 10px;
	font-weight: bold;
	text-align: center;
}

</style>