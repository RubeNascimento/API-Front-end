<template>
  <div class="footings">
    <v-footer class="foot"
      dark
      padless
    >
      <v-card
        class="flex"
        flat
        tile
      >
        <v-card-title class="teal">
          <strong class="subheading">Segue-nos nas redes sociais!</strong>

          <v-spacer></v-spacer>

          <v-btn
            v-for="icon in icons"
            :key="icon"
            class="mx-4 socials"
            dark
            icon
          >
            <v-icon size="24px">
              {{ icon }}
            </v-icon>
          </v-btn>
        </v-card-title>

        <v-card-text class="py-2 white--text text-center">
          {{ new Date().getFullYear() }} — <strong> &copy; Universidade da Madeira</strong>
        </v-card-text>
      </v-card>
    </v-footer>
  </div>
</template>

<style scoped>
.foot {
    min-width: 100%;
    text-align: center;
}
.footings {
  display: flex;
  justify-content: center;
  min-width: 100%;
}
.subheading {
  margin-left: 80px;
}
.socials {
  margin-right: 20px;
}
.teal {
  margin-top: 5px;
  height: 130px;
  display: flex;
  align-items: flex-start;
}
.v-card__title {
  display: flex;
  align-items: flex-start;
}
</style>

<script>
  export default {
    data: () => ({
      icons: [
        'mdi-facebook',
        'mdi-twitter',
        'mdi-linkedin',
        'mdi-instagram',
      ],
    }),
  }
</script>