<template>
  <v-container>
      <!-- Lista Produtos -->
      <div class="colunaProduct">
        <div class="grid_container">
          <v-card
            class="mx-auto my-12 margin_card"
            width="356px"
            outlined
            v-for="(item, index) in info"
            :key="index"
          >
            <v-card-title class="v-card-title">{{ item.dia }}</v-card-title>
            <v-card-text class="v-card-text">
              <v-row class="texto-botao">
                {{ item.feriado }}
              </v-row>
              <v-row class="texto-botao">
                {{ item.description }}
              </v-row>
            </v-card-text>
          </v-card>
        </div>
      </div>
  </v-container>
</template>

<script>
import Vue from "vue";
import VueMaterial from "vue-material";
import "vue-material/dist/vue-material.min.css";
import "vue-material/dist/theme/default.css";

Vue.use(VueMaterial);

import axios from "axios";
export default {
  name: "AutocompleteStatic",  
  data() {
    return {
      info: null,
    };
  },
  mounted() {
    axios
      .get(
        "https://apiprodutos-60469-default-rtdb.europe-west1.firebasedatabase.app/.json"
      )
      .then((response) => (this.info = response.data.data));
  },

};
</script>

<style scoped lang="scss">
html {
  height: auto;
}
.container {
  display: flex;
  justify-content: center;
}
.row {
  display: flex;
  margin-right: 30px;
}

.barra_search {
  display: flex;
  width: 200px;
  margin-left: 20px;
  margin-bottom: 20px;
  align-items: center;
}
.v-text-field {
  width: 50px;
}

.v-card-title {
  display: flex;
  justify-content: center;
}

.v-card-text {
  display: flex;
  flex-direction: column;
  align-items: center;
  p {
    margin-bottom: 7px;
  }
}

.margin_card {
  margin-bottom: 15px;
  text-align: center;
}

.colunaProduct {
  padding: 20px;
  display: flex;
  justify-content: center;
}

.grid_container {
  display: grid;
  grid-template-columns: auto auto auto;
  grid-column-gap: 20px;
}

.texto-botao {
  margin: 0;
}

.seleciona {
  width: 80px;
  margin-right: 10px;
}

.pesquisar {
  display: flex;
  justify-content: center;
  align-items: center;
  padding-bottom: 10px;
}

.paddingprodutos {
  padding-top: 20px;
}
</style>
