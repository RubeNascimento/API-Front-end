<template>
    <div id="app">
        <loading-screen v-if="isLoading"></loading-screen>
        <h1>Hello world!</h1>
    </div>
</template>

<style scoped lang="scss">
    body{
        margin: 0;
    }

#loading {
    background-color: #94C4CE;
    color: white;
    font-size: 32px;
    padding-top: 10vh;
    height: 100vh;
    text-align: center;
}
</style>

<script>
    Vue.component('loading-screen', {
        template: '<div id="loading">Loading...</div>'
    })

    new Vue({
    el: '#app',
    data: {
        isLoading: true
    },
    mounted () {
        setTimeout(() => {
        this.isLoading = false
        }, 3000)
    }
    })

</script>