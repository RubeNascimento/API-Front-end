<template>
  <div class="background">
    <form>
      <div class="meio">
        <div class="loginbackground">
          <h2 class="login" v-if="!signup">Iniciar sessão</h2>
          <h2 class="login" v-if="signup">Criar conta</h2>

          <v-card-text>
            <v-text-field class="inputt" label="Email" v-model="email_" />
            <v-text-field
              class="inputt"
              label="Password"
              type="password"
              v-model="password"
              required
              v-on:keyup.enter="start_login()"
            />
            <v-text-field
              class="inputt"
              label="Repeat password"
              type="password"
              v-if="signup"
              required
            />
          </v-card-text>
          <v-snackbar v-model="snackbar">
            {{ text }}

            <template v-slot:action="{ attrs }">
              <v-btn color="pink" v-bind="attrs" @click="snackbar = false">
                Close
              </v-btn>
            </template>
          </v-snackbar>

          <v-snackbar v-model="snackbar2">
            {{ text2 }}

            <template v-slot:action="{ attrs }">
              <v-btn color="pink" v-bind="attrs" @click="snackbar2 = false">
                Close
              </v-btn>
            </template>
          </v-snackbar>

          <v-card-actions>
            <v-btn type="button" v-if="!signup" @click="start_login()" outlined>
              <v-icon>mdi-login</v-icon>
            </v-btn>
            <v-btn type="button" v-if="signup" @click="start_signup()" outlined>
              <v-icon>mdi-check</v-icon>
            </v-btn>

            <div class="botoes">
              <v-a
                type="button"
                @click="desaparecer_signup()"
                outlined
                v-if="signup"
              >
                Iniciar sessão
              </v-a>
              <v-a
                type="button"
                @click="aparecer_signup()"
                outlined
                v-if="!signup"
              >
                Criar conta
              </v-a>
            </div>
          </v-card-actions>
        </div>
      </div>
    </form>
  </div>
</template>

<script>
import firebase from "firebase";
export default {
  data() {
    return {
      signup: false,
      email_: "",
      password: "",
      snackbar: false,
      snackbar2: false,
      text: "Erro de autenticação. Verifique novamente os seus dados.",
      text2:
        "Erro de criação de conta. Verifique se preencheu os campos corretamente.",
    };
  },
  methods: {
    aparecer_signup() {
      this.signup = true;
    },
    desaparecer_signup() {
      this.signup = false;
    },
    start_login() {
      firebase
        .auth()
        .signInWithEmailAndPassword(this.email_, this.password)
        .then((userCredential) => {
          // Signed in
          var user = userCredential.user;
          console.log(user);
          this.$router.push("/Produto");
        })
        .catch((error) => {
          var errorCode = error.code;
          var errorMessage = error.message;
          console.log(errorCode + errorMessage);
          this.snackbar = true;
        });
    },
    start_signup() {
      firebase
        .auth()
        .createUserWithEmailAndPassword(this.email_, this.password)
        .then((userCredential) => {
          // Signed in
          var user = userCredential.user;
          console.log(user);
          this.$router.push("/Produto");
          // ...
        })
        .catch((error) => {
          var errorCode = error.code;
          var errorMessage = error.message;
          console.log(errorCode + errorMessage);
          this.snackbar2 = true;
          // ..
        });
    },
    signout() {
      firebase
        .auth()
        .signOut()
        .then(() => {
          // Sign-out successful.
        })
        .catch((error) => {
          var errorCode = error.code;
          var errorMessage = error.message;
          console.log(errorCode + errorMessage);
          // An error happened.
        });
    },
  },
};
</script>

<style>
html {
  height: 800px;
}
.inputt {
  min-width: 520px;
}
.v-text__field {
  width: 500px;
}
.background {
  background-image: url(../assets/backgroundlogin.jpg);
  background-position-y: center;
  background-position-x: right;
  background-size: 100% 100%;
  height: 906px;
}
.loginbackground {
  background-image: url(../assets/calendarlogin.png);
  background-position: center;
  background-size: cover;
  border: 2px solid;
}
.meio {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 400px;
}
.login {
  display: flex;
  justify-content: center;
  padding: 10px;
}
.v-card--actions {
  display: flex;
  justify-content: space-between;
}
.botoes {
  display: flex;
  justify-content: flex-end;
  margin-right: 10px;
  margin-bottom: 10px;
  margin-left: 360px;
  text-decoration: underline black;
  color: black;
}
</style>
