<template>
  <div id="app">
    <v-app id="inspire">
      <v-main class="grey lighten-3">
        <v-form>
          <div class="meio">
            <v-card>
              <h2 class="login">Iniciar sessão</h2>
              <v-card-text>
                <v-text-field class="inputt" label="Username" />
                <v-text-field
                  class="inputt"
                  label="Password"
                  type="password"
                  required
                />
                <v-text-field
                  class="inputt"
                  label="Repeat password"
                  type="password"
                  v-if="signup"
                  required
                />
                <v-text-field class="inputt" label="Email" v-if="signup" />
              </v-card-text>
              <v-card-actions>
                <v-btn type="submit" outlined>
                  Login
                </v-btn>
                <v-btn type="button" @click="start_signup()" outlined>
                  Sign Up
                </v-btn>
              </v-card-actions>
            </v-card>
          </div>
        </v-form>
      </v-main>
    </v-app>
  </div>
</template>

<script>
export default {
  // props: ["id"],
  data() {
    return {
      signup: false,
    };
  },
  methods: {
    start_signup() {
      this.signup = true;
    },
  },
};
</script>

<style>
.inputt {
  width: 500px;
}

.meio {
  display: flex;
  justify-content: center;
  padding: 50px;
}
.login {
  display: flex;
  justify-content: center;
  padding: 10px;
}
</style>
