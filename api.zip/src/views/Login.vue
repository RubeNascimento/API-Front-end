<template>
  <v-app id="inspire">
    <v-main class="grey lighten-3">
      <v-form>
          <div class="meio">
            <v-card>
                <h2 class="login">Iniciar sessão</h2>
                <v-card-text>
                <v-text-field class="inputt" label="Username"/>
                <v-text-field class="inputt" label="Password" type="password" />
                <v-text-field class="inputt" label="Email"/>
                </v-card-text>
                <v-card-actions>
                <v-btn type="submit" outlined>
                    Login
                </v-btn>
                <v-btn type="submit" @click="sign_up()" outlined>
                    Sign Up
                </v-btn>
                </v-card-actions>
            </v-card>
        </div>
      </v-form>
    </v-main>
  </v-app>
</template>

<script>
export default {
    data: () => ({
        signup: false,
    }),
    methods: {
        sign_up () {
            this.signup = true;
        }
    }
}
</script>

<style>
    .inputt {
        width: 500px;
    }

    .meio {
        display: flex;
        justify-content: center;
        padding: 50px;
    }
    .login {
        display: flex;
        justify-content: center;
        padding: 10px;
    }
</style>