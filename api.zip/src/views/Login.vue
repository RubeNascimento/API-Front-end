<template>
  <div class="background">
    <form>
      <div class="meio">
        <div class="loginbackground">
          <h2 class="login">Iniciar sessão</h2>
          <v-card-text>
            <v-text-field class="inputt" label="Email" v-model="email_" />
            <v-text-field
              class="inputt"
              label="Password"
              type="password"
              v-model="password"
              required
              v-on:keyup.enter="start_login()"
            />
            <v-text-field
              class="inputt"
              label="Repeat password"
              type="password"
              v-if="signup"
              required
            />
          </v-card-text>
          <v-card-actions>
            <v-btn type="button" v-if="!signup" @click="start_login()" outlined>
              Confirm login
            </v-btn>
            <v-btn type="button" v-if="signup" @click="start_signup()" outlined>
              Confirm signup
            </v-btn>
            <div class="botoes">
              <v-btn
                class="botaologin"
                type="button"
                @click="desaparecer_signup()"
                outlined
              >
                Login
              </v-btn>
              <v-btn type="button" @click="aparecer_signup()" outlined>
                Sign Up
              </v-btn>
            </div>
          </v-card-actions>
        </div>
      </div>
    </form>
  </div>
</template>

<script>
import firebase from "firebase";
export default {
  data() {
    return {
      signup: false,
      email_: "",
      password: "",
    };
  },
  methods: {
    aparecer_signup() {
      this.signup = true;
    },
    desaparecer_signup() {
      this.signup = false;
    },
    start_login() {
      firebase
        .auth()
        .signInWithEmailAndPassword(this.email_, this.password)
        .then((userCredential) => {
          // Signed in
          var user = userCredential.user;
          console.log(user);
          this.$router.push("/Produto");
        })
        .catch((error) => {
          var errorCode = error.code;
          var errorMessage = error.message;
          console.log(errorCode + errorMessage);
        });
    },
    start_signup() {
      firebase
        .auth()
        .createUserWithEmailAndPassword(this.email_, this.password)
        .then((userCredential) => {
          // Signed in
          var user = userCredential.user;
          console.log(user);
          this.$router.push("/Produto");
          // ...
        })
        .catch((error) => {
          var errorCode = error.code;
          var errorMessage = error.message;
          console.log("nao deu" + errorCode + errorMessage);
          // ..
        });
    },
  },
};
</script>

<style>
html {
  height: 800px;
}
.inputt {
  width: 500px;
}
.background {
  background-image: url(../assets/backgroundlogin.jpg);
  background-position-y: center;
  background-position-x: right;
  background-size: 100% 100%;
  height: 906px;
}
.loginbackground {
  background-image: url(../assets/calendarlogin.png);
  background-position: center;
  background-size: cover;
  border: 2px solid;
}
.meio {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 400px;
}
.login {
  display: flex;
  justify-content: center;
  padding: 10px;
}
.botoes {
  width: 380px;
  display: flex;
  justify-content: flex-end;
}
.botaologin {
  display: flex;
  margin-right: 8px;
}
</style>
