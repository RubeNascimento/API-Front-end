<template>
  <div class="backgroundabout">
    <div class="about">
        <md-dialog :md-active.sync="showDialog">
        <div class="icone_titulo">
          <v-icon class="icone">mdi-information-outline </v-icon>
          <h1>Sobre</h1>
        </div>
        <p class="paragrafodentro">Este é um website onde podes encontrar os feriados da Região Autónoma da Madeira, assim como os feriados de cada país.</p>
        <md-dialog-actions>
          <button class="botaodentro" @click="showDialog = false">Fechar</button>
        </md-dialog-actions>
      </md-dialog>

        <button class="botaoabout" @click="showDialog = true">

            <v-icon class="icone">mdi-information-outline </v-icon>
            <h1>Sobre</h1>

        </button>
    </div>

    <div class="about">
        <md-dialog :md-active.sync="showDialog2">
        <div class="icone_titulo">
          <v-icon class="icone">mdi-account-voice</v-icon>
          <h1>Redes Sociais</h1>
        </div>
        <p class="paragrafodentro">Segue-nos nas redes sociais:</p>
        <div class="botaosocials">
          <v-btn
            v-for="icon in icons"
            :key="icon"
            class=" socials"
            dark
            icon
          >
            <v-icon size="24px">
              {{ icon }}
            </v-icon>
          </v-btn>
        </div>
        <md-dialog-actions>
          <button class="botaodentro" @click="showDialog2 = false">Fechar</button>
        </md-dialog-actions>
      </md-dialog>

        <button class="botaoabout" @click="showDialog2 = true">

            <v-icon class="icone">mdi-account-voice</v-icon>
            <h1>Redes Sociais</h1>

        </button>
    </div>

     <div class="about">
        <md-dialog :md-active.sync="showDialog3">
        <div class="icone_titulo">
          <v-icon class="icone">mdi-message-question-outline</v-icon>
          <h1>Ajuda</h1>
        </div>
        <p class="paragrafodentro">Descreve-nos o teu problema:</p>
        <div class="textomeioduvida">
          <input class="inputduvida" type="text">
        </div>
        <md-dialog-actions>
          <button class="botaodentro" @click="showDialog3 = false">Enviar</button>
          <button class="botaodentro" @click="showDialog3 = false">Fechar</button>
        </md-dialog-actions>
      </md-dialog>

        <button class="botaoabout" @click="showDialog3 = true">

            <v-icon class="icone">mdi-message-question-outline</v-icon>
            <h1>Ajuda</h1>

        </button>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'DialogCustom',
    data: () => ({
      showDialog: false,
      showDialog2: false,
      showDialog3: false,
      icons: [
        'mdi-facebook',
        'mdi-twitter',
        'mdi-linkedin',
        'mdi-instagram',
      ],
    })
}
</script>

<style scoped lang="scss">
.backgroundabout {
  height: 910px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: #94c4ce;
  padding-top: 100px;
  padding-bottom: 100px;
}
.about{
  height: 100px;
  width: 600px;
  text-align: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 10px;
}
.icone_titulo {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 10px;
}
.icone {
  font-size: 27px;
  margin-right: 7px;
  color: black;
}

.botaoabout {
  border-radius: 7px;
  width: 300px;
  height: 50px;
  border: 2px solid black;
  display: flex;
  justify-content: center;
  align-items: center;
  box-shadow: rgba(44, 44, 44, 0.1) 3px 3px 3px 3px;
}
.botaoabout:hover {
  background-color: #739da5;
}

.botaodentro {
  border: 1px solid black;
  border-radius: 3px;
  padding: 5px;
  margin-left: 5px;
}
.botaodentro:hover {
  background-color: rgb(211, 211, 211);
}
.paragrafodentro {
  text-align: center;
  margin: 10px;
}
.socials {
  background-color: black;
}
.botaosocials {
  display: flex;
  justify-content: space-around;
}
.inputduvida {
  display: flex;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: start;
  border: 1px solid black;
  border-radius: 3px;
  width: 1000px;
  padding: 6px 8px;
  box-sizing: border-box;
  margin: 10px;
}
.textomeioduvida{
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
