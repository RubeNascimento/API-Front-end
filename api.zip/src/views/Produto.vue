<template>
  <v-container>

    <div class='barra_search'>
      <v-text-field class='row' type="text" v-model="pais" ></v-text-field>
      <v-btn class="ma-2 row" outlined color="indigo" @click="procura(pais)">
        Search
      </v-btn>
    </div>


    <div class="row">
      <!-- Lista Produtos -->

      <v-snackbar v-model="snackbar">
        {{ text }}

        <template v-slot:action="{ attrs }">
          <v-btn color="pink" v-bind="attrs" @click="snackbar = false">
            Close
          </v-btn>
        </template>
      </v-snackbar>
      <div class="colunaProduct">
        <v-card
          class="mx-auto my-12"
          v-for="(item, index) in info"
          :key="index"
        >
          <v-card-title>{{ item.name }}</v-card-title>
          <v-card-text>
            <v-row>
              {{ item.date }}
            </v-row>
            <v-row>
              {{ item.location }}
            </v-row>
            <v-row>
              {{ item.type }}
            </v-row>
          </v-card-text>
          <v-card-actions>
            <v-btn icon color="pink" @click="adiciona_favorito(item)">
              <v-icon>mdi-heart</v-icon>
            </v-btn>
          </v-card-actions>
        </v-card>
      </div>

      <!-- Lista favoritos -->
      <div class="colunaFav">
        <div v-if="favoritos.length > 0">
          <h3>Favoritos</h3>
          <div v-for="(item, index) in favoritos" :key="index">
            {{ item.name }} - {{item.location}} - {{ item.date }}
            <v-icon x-small @click="removeFav(index)"
              >mdi-close-circle-outline</v-icon
            >
          </div>
        </div>
      </div>
    </div>
  </v-container>
</template>

<style>
.row {
  display: flex;
  margin-right: 30px;
}

.barra_search {
  display: flex;
  width: 200px;
  margin-left: 20px;
}

.v-text-field {
  width: 50px;
}

.colunaFav {
  flex: 50%;
  padding: 20px;
}

.colunaProduct {
  flex: 50%;
  padding: 20px;
}
</style>

<script>
import axios from "axios";
export default {
  // props: ["id"],
  data() {
    return {
      favoritos: [],
      show: false,
      info: null,
      snackbar: false,
      text: `Esse item já foi adicionado aos favoritos!`,
      country: "PT",
      countries: [
        { country: "Portugal", code: "PT" },
        { country: "Estados Unidos", code: "US" },
      ],
      year: 2020,
      month: 12,
      day: 25,
    };
  },
  mounted() {
    axios
      .get(
        "https://holidays.abstractapi.com/v1/?api_key=cfb10a1a8f28483b8ce5140fbbf1900f&country=" +
          this.country +
          "&year=" +
          this.year
      )
      .then((response) => (this.info = response.data));
  },
  methods: {
    adiciona_favorito(index) {
      if (this.favoritos.indexOf(index) === -1) {
        this.favoritos.push(index);
      } else {
        this.snackbar = true;
      }
      console.log(this.favoritos);
    },
    removeFav(index) {
      this.favoritos.splice(index, 1);
    },
    procura(pais) {
      axios
        .get(
          "https://holidays.abstractapi.com/v1/?api_key=cfb10a1a8f28483b8ce5140fbbf1900f&country=" +
            pais +
            "&year=" +
            this.year +
            ""
        )
        .then((response) => (this.info = response.data));
    },
  },
};
</script>
