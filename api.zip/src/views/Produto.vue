<template>
  <v-container>

    <div class='barra_search'>
      <v-text-field class='row' type="text" v-model="pais" v-on:keyup.enter="procura(pais)"></v-text-field>
      <v-btn class="ma-2 row" outlined color="indigo" @click="procura(pais)">
        Search
      </v-btn>
    </div>


    <div class="row">

      <div class='colunaPaises'>
        <h3>Lista de Países</h3>
        <p>Afghanistan - AF</p>
        <p>Albania - AL</p>
        <p>Algeria - DZ</p>
        <p>American Samoa - AS</p>
        <p>Andorra - AD</p>
        <p>Angola - AO</p>
        <p>Anguilla - AI</p>
        <p>Antigua and Barbuda - AG</p>
        <p>Argentina - AR</p>
        <p>Armenia - AM</p>
        <p>Aruba - AW</p>
        <p>Australia - AU</p>
        <p>Austria - AT</p>
        <p>Azerbaijan - AZ</p>
        <p>Bahrain - BH</p>
        <p>Bangladesh - BD</p>
        <p>Barbados - BB</p>
        <p>Belarus - BY</p>
        <p>Belgium - BE</p>
        <p>Belize - BZ</p>
        <p>Benin - BJ</p>
        <p>Bermuda - BM</p>
        <p>Bhutan - BT</p>
        <p>Bolivia - BO</p>
        <p>Bosnia and Herzegovina - BA</p>
        <p>Botswana - BW</p>
        <p>Brazil - BR</p>
        <p>British Virgin Islands - VG</p>
        <p>Brunei - BN</p>
        <p>Bulgaria - BG</p>
        <p>Burkina Faso - BF</p>
        <p>Burundi - BI</p>
        <p>Cabo Verde - CV</p>
        <p>Cambodia - KH</p>
        <p>Cameroon - CM</p>
        <p>Canada - CA</p>
        <p>Cayman Islands - KY</p>
        <p>Central African Republic - CF</p>
        <p>Chad - TD</p>
        <p>Chile - CL</p>
        <p>China - CN</p>
        <p>Colombia - CO</p>
        <p>Comoros - KM</p>
        <p>Congo - CG</p>
        <p>Congo Democratic Republic - CD</p>
        <p>Cook Islands - CK</p>
        <p>Costa Rica - CR</p>
        <p>Cote d'Ivoire - CI</p>
        <p>Croatia - HR</p>
        <p>Cuba - CU</p>
        <p>Curaçao - CW</p>
        <p>Cyprus - CY</p>
        <p>Czechia - CZ</p>
        <p>Denmark - DK</p>
        <p>Djibouti - DJ</p>
        <p>Dominica - DM</p>
        <p>Dominican Republic - DO</p>
        <p>East Timor - TL</p>
        <p>Ecuador - EC</p>
        <p>Egypt - EG</p>
        <p>El Salvador - SV</p>
        <p>Equatorial Guinea - GQ</p>
        <p>Eritrea - ER</p>
        <p>Estonia - EE</p>
        <p>eSwatini - SZ</p>
        <p>Ethiopia - ET</p>
        <p>Falkland Islands - FK</p>
        <p>Faroe Islands - FO</p>
        <p>Fiji - FJ</p>
        <p>Finland - FI</p>
        <p>France - FR</p>
        <p>French Guiana - GF</p>
        <p>French Polynesia - PF</p>
        <p>Gabon - GA</p>
        <p>Gambia - GM</p>
        <p>Georgia - GE</p>
        <p>Germany - DE</p>
        <p>Ghana - GH</p>
        <p>Gibraltar - GI</p>
        <p>Greece - GR</p>
        <p>Greenland - GL</p>
        <p>Grenada - GD</p>
        <p>Guadeloupe - GP</p>
        <p>Guam - GU</p>
        <p>Guatemala - GT</p>
        <p>Guernsey - GG</p>
        <p>Guinea - GN</p>
        <p>Guinea-Bissau - GW</p>
        <p>Guyana - GY</p>
        <p>Haiti - HT</p>
        <p>Honduras - HN</p>
        <p>Hong Kong - HK</p>
        <p>Hungary - HU</p>
        <p>Iceland - IS</p>
        <p>India - IN</p>
        <p>Indonesia - ID</p>
        <p>Iran - IR</p>
        <p>Iraq - IQ</p>
        <p>Ireland - IE</p>
        <p>Isle of Man - IM</p>
        <p>Israel - IL</p>
        <p>Italy - IT</p>
        <p>Jamaica - JM</p>
        <p>Japan - JP</p>
        <p>Jersey - JE</p>
        <p>Jordan - JO</p>
        <p>Kazakhstan - KZ</p>
        <p>Kenya - KE</p>
        <p>Kiribati - KI</p>
        <p>Kosovo - XK</p>
        <p>Kuwait - KW</p>
        <p>Kyrgyzstan - KG</p>
        <p>Laos - LA</p>
        <p>Latvia - LV</p>
        <p>Lebanon - LB</p>
        <p>Lesotho - LS</p>
        <p>Liberia - LR</p>
        <p>Libya - LY</p>
        <p>Liechtenstein - LI</p>
        <p>Lithuania - LT</p>
        <p>Luxembourg - LU</p>
        <p>Macau - MO</p>
        <p>Madagascar - MG</p>
        <p>Malawi - MW</p>
        <p>Malaysia - MY</p>
        <p>Maldives - MV</p>
        <p>Mali - ML</p>
        <p>Malta - MT</p>
        <p>Marshall Islands - MH</p>
        <p>Martinique - MQ</p>
        <p>Mauritania - MR</p>
        <p>Mauritius - MU</p>
        <p>Mayotte - YT</p>
        <p>Mexico - MX</p>
        <p>Micronesia - FM</p>
        <p>Moldova - MD</p>
        <p>Monaco - MC</p>
        <p>Mongolia - MN</p>
        <p>Montenegro - ME</p>
        <p>Montserrat - MS</p>
        <p>Morocco - MA</p>
        <p>Mozambique - MZ</p>
        <p>Myanmar - MM</p>
        <p>Namibia - NA</p>
        <p>Nauru - NR</p>
        <p>Nepal - NP</p>
        <p>Netherlands - NL</p>
        <p>New Caledonia - NC</p>
        <p>New Zealand - NZ</p>
        <p>Nicaragua - NI</p>
        <p>Niger - NE</p>
        <p>Nigeria - NG</p>
        <p>North Korea - KP</p>
        <p>North Macedonia - MK</p>
        <p>Northern Mariana Islands - MP</p>
        <p>Norway - NO</p>
        <p>Oman - OM</p>
        <p>Pakistan - PK</p>
        <p>Palau - PW</p>
        <p>Panama - PA</p>
        <p>Papua New Guinea - PG</p>
        <p>Paraguay - PY</p>
        <p>Peru - PE</p>
        <p>Philippines - PH</p>
        <p>Poland - PL</p>
        <p>Portugal - PT</p>
        <p>Puerto Rico - PR</p>
        <p>Qatar - QA</p>
        <p>Reunion - RE</p>
        <p>Romania - RO</p>
        <p>Russia - RE</p>
        <p>Rwanda - RW</p>
        <p>Saint Helena - SH</p>
        <p>Saint Kitts and Nevis - KN</p>
        <p>Saint Lucia - LC</p>
        <p>Saint Martin - MF</p>
        <p>Saint Pierre and Miquelon - PM</p>
        <p>Saint Vincent and the Grenadines - VC</p>
        <p>Samoa - WS</p>
        <p>San Marino - SM</p>
        <p>Sao Tome and Principe - ST</p>
        <p>Saudi Arabia - SA</p>
        <p>Senegal - SN</p>
        <p>Serbia - RS</p>
        <p>Seychelles - SC</p>
        <p>Sierra Leone - SL</p>
        <p>Singapore - SG</p>
        <p>Sint Maarten - SX</p>
        <p>Slovakia - SK</p>
        <p>Slovenia - SI</p>
        <p>Solomon Islands - SB</p>
        <p>Somalia - SO</p>
        <p>South Africa - ZA</p>
        <p>South Korea - KR</p>
        <p>South Sudan - SS</p>
        <p>Spain - ES</p>
        <p>Sri Lanka - LK</p>
        <p>St. Barts - BL</p>
        <p>Sudan - SD</p>
        <p>Suriname - SR</p>
        <p>Sweden - SE</p>
        <p>Switzerland - CH</p>
        <p>Syria - SY</p>
        <p>Taiwan - TW</p>
        <p>Tajikistan - TJ</p>
        <p>Tanzania - TZ</p>
        <p>Thailand - TH</p>
        <p>The Bahamas - BH</p>
        <p>Togo - TG</p>
        <p>Tonga - TO</p>
        <p>Trinidad and Tobago - TT</p>
        <p>Tunisia - TN</p>
        <p>Turkey - TR</p>
        <p>Turkmenistan - TM</p>
        <p>Turks and Caicos Islands - TC</p>
        <p>Tuvalu - TV</p>
        <p>Uganda - UG</p>
        <p>Ukraine - UA</p>
        <p>United Arab Emirates - AE</p>
        <p>United Kingdom - GB</p>
        <p>United States - US</p>
        <p>Uruguay - UY</p>
        <p>US Virgin Islands - VI</p>
        <p>Uzbekistan - UZ</p>
        <p>Vanuatu - VU</p>
        <p>Vatican City (Holy See) - VA</p>
        <p>Venezuela - VE</p>
        <p>Vietnam - VN</p>
        <p>Wallis and Futuna - WF</p>
        <p>Yemen - YE</p>
        <p>Zambia - ZM</p>
        <p>Zimbabwe - ZW</p>
      </div>



      <!-- Lista Produtos -->

      <v-snackbar v-model="snackbar">
        {{ text }}

        <template v-slot:action="{ attrs }">
          <v-btn color="pink" v-bind="attrs" @click="snackbar = false">
            Close
          </v-btn>
        </template>
      </v-snackbar>
      <div class="colunaProduct">
        <v-card
          class="mx-auto my-12 margin_card" width="350px" outlined
          v-for="(item, index) in info"
          :key="index"
        >
          <v-card-title class='v-card-title'>{{ item.name }}</v-card-title>
          <v-card-text class='v-card-text'>
            <v-row>
              {{ item.date }}
            </v-row>
            <v-row>
              {{ item.location }}
            </v-row>
            <v-row>
              {{ item.type }}
            </v-row>
          </v-card-text>
          <v-card-actions>
            <v-btn icon color="pink" @click="adiciona_favorito(item)">
              <v-icon>mdi-heart</v-icon>
            </v-btn>
          </v-card-actions>
        </v-card>
      </div>

      



      <!-- Lista favoritos -->
      <div class="colunaFav">
        <div v-if="favoritos.length > 0">
          <h3>Favoritos</h3>
          <div v-for="(item, index) in favoritos" :key="index">
            {{ item.name }} - {{item.location}} - {{ item.date }}
            <v-icon x-small @click="removeFav(index)"
              >mdi-close-circle-outline</v-icon
            >
          </div>
        </div>
      </div>
    </div>
  </v-container>
</template>

<style>
html {
  height: auto;
}
.row {
  display: flex;
  margin-right: 30px;
}

.barra_search {
  display: flex;
  width: 200px;
  margin-left: 20px;
  margin-bottom: 20px;
}

.v-text-field {
  width: 50px;
}

.v-card-title {
  display: flex;
  justify-content: center;
}

.v-card-text {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.margin_card {
  display: flex;
  margin-bottom: 15px;
}

.colunaPaises {
  flex: 20%;
  padding: 10px;
}

.colunaFav {
  flex: 30%;
  padding: 20px;
}

.colunaProduct {
  flex: 15%;
  padding: 20px;
}
</style>

<script>
import axios from "axios";
export default {
  // props: ["id"],
  data() {
    return {
      favoritos: [],
      show: false,
      info: null,
      snackbar: false,
      text: `Esse item já foi adicionado aos favoritos!`,
      country: "PT",
      countries: [
        { country: "Portugal", code: "PT" },
        { country: "Estados Unidos", code: "US" },
      ],
      year: 2020,
      month: 12,
      day: 25,
    };
  },
  mounted() {
    axios
      .get(
        "https://holidays.abstractapi.com/v1/?api_key=cfb10a1a8f28483b8ce5140fbbf1900f&country=" +
          this.country +
          "&year=" +
          this.year
      )
      .then((response) => (this.info = response.data));
  },
  methods: {
    adiciona_favorito(index) {
      if (this.favoritos.indexOf(index) === -1) {
        this.favoritos.push(index);
      } else {
        this.snackbar = true;
      }
      console.log(this.favoritos);
    },
    removeFav(index) {
      this.favoritos.splice(index, 1);
    },
    procura(pais) {
      axios
        .get(
          "https://holidays.abstractapi.com/v1/?api_key=cfb10a1a8f28483b8ce5140fbbf1900f&country=" +
            pais +
            "&year=" +
            this.year +
            ""
        )
        .then((response) => (this.info = response.data));
    },
  },
};
</script>
