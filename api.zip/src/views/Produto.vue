<template>
  <v-container>
    <div class="row pesquisar">
      <md-autocomplete
        v-model="selectedCountry"
        :md-options="countries"
        class="seleciona"
      >
        <label>Country</label>
      </md-autocomplete>
      <v-btn outlined color="indigo" @click="procura(selectedCountry)">
        <v-icon>mdi-magnify</v-icon>
      </v-btn>
    </div>

    <hr />

    <div class="row paddingprodutos">
      <v-snackbar v-model="snackbar">
        {{ text }}

        <template v-slot:action="{ attrs }">
          <v-btn color="pink" v-bind="attrs" @click="snackbar = false">
            Close
          </v-btn>
        </template>
      </v-snackbar>

      <!-- Lista favoritos -->
      <div class="colunaFav">
        <h3>Favoritos</h3>
        <div v-if="favoritos.length > 0">
          <div v-for="(item, index) in favoritos" :key="index">
            {{ item.name }} - {{ item.location }} - {{ item.date }}
            <v-icon x-small @click="removeFav(index)"
              >mdi-close-circle-outline</v-icon
            >
          </div>
        </div>
      </div>

      <!-- Lista Produtos -->
      <div class="colunaProduct">
        <div class="grid_container">
          <v-card
            class="mx-auto my-12 margin_card"
            width="356px"
            outlined
            v-for="(item, index) in info"
            :key="index"
          >
            <v-card-title class="v-card-title">{{ item.name }}</v-card-title>
            <v-card-text class="v-card-text">
              <p>m / d / y</p>
              <v-row class="texto-botao">
                {{ item.date }}
              </v-row>
              <v-row class="texto-botao">
                {{ item.location }}
              </v-row>
              <v-row class="texto-botao">
                {{ item.type }}
              </v-row>
            </v-card-text>
            <v-card-actions>
              <v-btn icon color="pink" @click="adiciona_favorito(item)">
                <v-icon>mdi-heart</v-icon>
              </v-btn>
            </v-card-actions>
          </v-card>
        </div>
      </div>
    </div>
  </v-container>
</template>

<script>
import Vue from "vue";
import VueMaterial from "vue-material";
import "vue-material/dist/vue-material.min.css";
import "vue-material/dist/theme/default.css";

Vue.use(VueMaterial);
import axios from "axios";
export default {
  name: "AutocompleteStatic",
  data() {
    return {
      selectedCountry: null,
      selectedEmployee: null,
      countries: [
        "AF",
        "AL",
        "DZ",
        "AS",
        "AD",
        "AO",
        "AI",
        "AG",
        "AR",
        "AM",
        "AW",
        "AU",
        "AT",
        "AZ",
        "BH",
        "BD",
        "BB",
        "BY",
        "BE",
        "BZ",
        "BJ",
        "BM",
        "BT",
        "BO",
        "BA",
        "BW",
        "BR",
        "VG",
        "BN",
        "BG",
        "BF",
        "BI",
        "CV",
        "KH",
        "CM",
        "CA",
        "KY",
        "CF",
        "TD",
        "CL",
        "CN",
        "CO",
        "KM",
        "CG",
        "CD",
        "CK",
        "CR",
        "CI",
        "HR",
        "CU",
        "CW",
        "CY",
        "CZ",
        "DK",
        "DJ",
        "DM",
        "DO",
        "TL",
        "EC",
        "EG",
        "SV",
        "GQ",
        "ER",
        "EE",
        "SZ",
        "ET",
        "FK",
        "FO",
        "FJ",
        "FI",
        "FR",
        "GF",
        "PF",
        "GA",
        "GM",
        "GE",
        "DE",
        "GH",
        "GI",
        "GR",
        "GL",
        "GD",
        "GP",
        "GU",
        "GT",
        "GG",
        "GN",
        "GW",
        "GY",
        "HT",
        "HN",
        "HK",
        "HU",
        "IS",
        "IN",
        "ID",
        "IR",
        "IQ",
        "IE",
        "IM",
        "IL",
        "IT",
        "JM",
        "JP",
        "JE",
        "JO",
        "KZ",
        "KE",
        "KI",
        "XK",
        "KW",
        "KG",
        "LA",
        "LV",
        "LB",
        "LS",
        "LR",
        "LY",
        "LI",
        "LT",
        "LU",
        "MO",
        "MG",
        "MW",
        "MY",
        "MV",
        "ML",
        "MT",
        "MH",
        "MQ",
        "MR",
        "MU",
        "YT",
        "MX",
        "FM",
        "MD",
        "MC",
        "MN",
        "ME",
        "MS",
        "MA",
        "MZ",
        "MM",
        "NA",
        "NR",
        "NP",
        "NL",
        "NC",
        "NZ",
        "NI",
        "NE",
        "NG",
        "KP",
        "MK",
        "MP",
        "NO",
        "OM",
        "PK",
        "PW",
        "PA",
        "PG",
        "PY",
        "PE",
        "PH",
        "PL",
        "PT",
        "PR",
        "QA",
        "RE",
        "RO",
        "RE",
        "RW",
        "SH",
        "KN",
        "LC",
        "MF",
        "PM",
        "VC",
        "WS",
        "SM",
        "ST",
        "SA",
        "SN",
        "RS",
        "SC",
        "SL",
        "SG",
        "SX",
        "SK",
        "SI",
        "SB",
        "SO",
        "ZA",
        "KR",
        "SS",
        "ES",
        "LK",
        "BL",
        "SD",
        "SR",
        "SE",
        "CH",
        "SY",
        "TW",
        "TJ",
        "TZ",
        "TH",
        "BH",
        "TG",
        "TO",
        "TT",
        "TN",
        "TR",
        "TM",
        "TC",
        "TV",
        "UG",
        "UA",
        "AE",
        "GB",
        "US",
        "UY",
        "VI",
        "UZ",
        "VU",
        "VA",
        "VE",
        "VN",
        "WF",
        "YE",
        "ZM",
        "ZW",
      ],
      favoritos: [],
      show: false,
      info: null,
      snackbar: false,
      text: `Esse item já foi adicionado aos favoritos!`,
      country: "PT",
      year: 2020,
      month: 12,
      day: 25,
    };
  },
  mounted() {
    axios
      .get(
        "https://holidays.abstractapi.com/v1/?api_key=cfb10a1a8f28483b8ce5140fbbf1900f&country=" +
          this.country +
          "&year=" +
          this.year
      )
      .then((response) => (this.info = response.data));
  },
  methods: {
    adiciona_favorito(index) {
      if (this.favoritos.indexOf(index) === -1) {
        this.favoritos.push(index);
      } else {
        this.snackbar = true;
      }
      console.log(this.favoritos);
    },
    removeFav(index) {
      this.favoritos.splice(index, 1);
    },
    procura(selectedCountry) {
      axios
        .get(
          "https://holidays.abstractapi.com/v1/?api_key=cfb10a1a8f28483b8ce5140fbbf1900f&country=" +
            selectedCountry +
            "&year=" +
            this.year +
            ""
        )
        .then((response) => (this.info = response.data));
    },
  },
};
</script>

<style lang="scss">
html {
  height: auto;
}
.row {
  display: flex;
  margin-right: 30px;
}

.barra_search {
  display: flex;
  width: 200px;
  margin-left: 20px;
  margin-bottom: 20px;
  align-items: center;
}

.v-text-field {
  width: 50px;
}

.v-card-title {
  display: flex;
  justify-content: center;
}

.v-card-text {
  display: flex;
  flex-direction: column;
  align-items: center;
  p {
    margin-bottom: 7px;
  }
}

.margin_card {
  display: flex;
  margin-bottom: 15px;
  text-align: center;
}

.colunaFav {
  flex: 25%;
  padding: 20px;
}

.colunaProduct {
  flex: 75%;
  padding: 20px;
}

.grid_container {
  display: grid;
  grid-template-columns: auto auto auto;
}

.texto-botao {
  margin: 0;
}

.seleciona {
  width: 80px;
  margin-right: 10px;
}

.pesquisar {
  display: flex;
  justify-content: center;
  align-items: center;
  padding-bottom: 10px;
}

.paddingprodutos {
  padding-top: 20px;
}
</style>
