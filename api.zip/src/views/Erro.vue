<template>
    <div>
        <div class="mySocial">
            <a href="https://www.linkedin.com/in/rominamartinliberon/" target="_new" class="social">
                <i class="fab fa-linkedin"></i>
            </a>
            <a href="https://rominamartin.github.io/" target="_new" class="social">
                <i class="fab fa-github"></i>
            </a>
            <a href="https://twitter.com/rominamartinlib" target="_new" class="social">
                <i class="fab fa-twitter"></i>
            </a>
        </div>

        <div class="container">
            <div class="controls">
                <div class="reset">
                <i class="fas fa-redo"></i>
                <span>Reset</span>
                </div>
            </div>
            <div class="calendar animate">
                <div class="shadow"></div>
                <div class="top">
                <div class="left ring"></div>
                <div class="right ring"></div>
                </div>
                <div class="page">
                <span class="title">Lockdown</span>
                <span class="title"> ERROR 404</span>
                <span id="days"></span>
                </div>
            </div>
        </div>
    </div>
</template>

<style scoped lang="scss">
    .mySocial {
  position: absolute;
  top: 25px;
  left: 25px;

  a {
    display: inline-block;
    height: 2.5em;
  }
  a i {
    font-size: 1.5em;
    &.fa-linkedin {
      color: #fff;
    }
    &.fa-github {
      color: #24292e;
    }
    &.fa-twitter {
      color: #1da1f2;
    }
  }
}

body {
  width: 100%;
  height: 100vh;
  background: #5952fd;
  overflow: hidden;
  font-family: "Poppins", sans-serif;
  display: flex;
  align-items: center;
}

.container {
  width: 100%;
  height: 450px;
  display: grid;
  align-items: center;
  justify-content: center;
  grid-template-rows: 50px 400px;
}

.calendar {
  width: 400px;
  height: 400px;
  margin: auto;
  background: white;
  position: relative;

  &.animate {
    animation: scale 0.4s infinite linear;
  }

  .shadow {
    position: absolute;
    width: 566px;
    height: 1000px;
    top: 50px;
    left: 270px;
    z-index: -1;
    transform: rotate(-45deg);
  }
}

.reset {
  color: white;

  i,
  span {
    pointer-events: none;
  }

  &:hover {
    color: #ccc;
    cursor: pointer;
  }
}

.top {
  height: 80px;
  width: 100%;
  background: #94c4ce;
  position: relative;
  box-shadow: 0px 6px 2px #d5d5d5;

  &::before {
    content: "";
    position: absolute;
    height: 100%;
    width: 50%;
    right: 0;
    top: 0;
    background: #8ab9c4;
  }

  .ring {
    position: absolute;
    width: 40px;
    height: 40px;
    background: #5952fd;
    border-radius: 50%;
    top: 20px;

    &::before {
      content: "";
      position: absolute;
      top: -35px;
      height: 60px;
      width: 25%;
      left: 25%;
      background: #404041;
      border-radius: 20px 0 0 20px;
    }
    &::after {
      content: "";
      position: absolute;
      top: -35px;
      height: 60px;
      width: 25%;
      right: 25%;
      background: #1e1b1d;
      border-radius: 0 20px 20px 0;
    }

    &.left {
      left: 80px;
    }
    &.right {
      right: 80px;
    }
  }
}
.page {
  width: 100%;
  height: 320px;
  text-align: center;
  display: grid;
  grid-template-rows: 60px 260px;
  align-items: center;
  background: white;
  box-shadow: 0 5px 30px rgba(0,0,0,.1);

  .title {
    font-size: 2em;
    text-transform: uppercase;
    font-weight: bold;
    color: #3c3c3c;
  }

  #days {
    font-size: 250px;
    line-height: 250px;
  }
}

@keyframes scale {
  from {
    transform: scale(0.98);
  }
  to {
    transform: scale(1);
  }
}

</style>

<script>

</script>