<template>
  <div class="app">
    <div v-for="(artigo, index) in artigos" :key="index">
      {{ artigo }}
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  components: {},
  data() {
    return {
      artigos: "",
    };
  },
  mounted() {
    return axios
      .get(
        "https://apiprodutos-60469-default-rtdb.europe-west1.firebasedatabase.app/.json"
      )
      .then((res) => {
        this.artigos = res.data;
      });
  },
};
</script>

<style scoped>
.app {
  margin-top: 4.5rem;
  display: flex;
  align-items: center;
  flex-direction: column;
}
</style>
