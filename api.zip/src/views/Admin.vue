<template>
  <form @submit.prevent="submeterFeriado">
    <div class="backgroundAdmin">
      <div class="adminsubmit">
        <h1>Admin</h1>
        <h2>Adicionar feriado regional</h2>
        <div class="inputs">
          <div class="feriado">
            <input class="iinput" type="text" placeholder="Nome do feriado" v-model="novoFeriado.feriado">
          </div>
          <div class="dia">
            <input class="iiinput" type="text" placeholder="Descrição do feriado (opcional)" v-model="novoFeriado.description">
          </div>
          <div class="dia">
            <input type="date" class="inputdata" placeholder="Data" v-model="novoFeriado.dia">
          </div>
          <v-btn class="botao" outlined color="pink" v-if="novoFeriado.feriado.length > 0 && novoFeriado.dia.length > 0" @click="submeterFeriado()" onClick="self.location.assign(window.location)">Submit</v-btn>
        </div>
      </div>
    </div>
  </form>
</template>

<script>
import axios from 'axios';
export default {
  data () {
    return {
      novoFeriado: {
      feriado: '',
      dia: '',
      description: ''
      }
    }
  },
  methods: {
    submeterFeriado(){
      let mesFormadado = '';


      let split = this.novoFeriado.dia.split(' '); //separa a data da hora
      let formmated = split[0].split('-');
      let mes = formmated[1];
      console.log(formmated[2]+'-'+formmated[1]+'-'+formmated[0]);
      if(mes == 1){
        mesFormadado = 'Janeiro';
      }
      else if(mes == 2){
        mesFormadado = 'Fevereiro';
      }
      else if(mes == 3){
        mesFormadado = 'Março';
      }
      else if(mes == 4){
        mesFormadado = 'Abril';
      }
      else if(mes == 5){
        mesFormadado = 'Maio';
      }
      else if(mes == 6){
        mesFormadado = 'Junho';
      }
      else if(mes == 7){
        mesFormadado = 'Julho';
      }
      else if(mes == 8){
        mesFormadado = 'Agosto';
      }
      else if(mes == 9){
        mesFormadado = 'Setembro';
      }
      else if(mes == 10){
        mesFormadado = 'Outubro';
      }
      else if(mes == 11){
        mesFormadado = 'Novembro';
      }
      else if(mes == 12){
        mesFormadado = 'Dezembro';
      }

       this.novoFeriado.dia = formmated[2] + " de " + mesFormadado;

      return axios.post('https://apiprodutos-60469-default-rtdb.europe-west1.firebasedatabase.app/data.json', this.novoFeriado, this.$router.push("/FeriadosRegionais"));
    }
  }
};
</script>

<style scoped lang="scss">
 .backgroundAdmin {
   display: flex;
   flex-direction: column;
   align-items: center;
   height: 966px;
 }
 h1{
   padding-bottom: 50px;
 }
 .inputdata {
   outline: none;
   border: 2px solid black;
 }
 .iinput {
   border: solid 2px black;
   margin-left: 5px;
 }
  .iiinput {
  width: 300px;
   border: solid 2px black;
   margin-left: 5px;
 }
 .adminsubmit {
   display: flex;
   flex-direction: column;
   align-items: center;
   padding: 10px;
 }
 .feriado {
   padding: 8px;
   display: flex;
   justify-content: space-between;
   align-items: center;
 }
 .dia {
   padding: 8px;
   display: flex;
   align-items: center;
 }
 .inputs{
   display: flex;
   flex-direction: column;
   align-items: center;
   margin-top: 10px;
 }
 .botao {
   margin-top: 10px;
   margin-right: 8px;
 }
</style>
