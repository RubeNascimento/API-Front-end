<template>
  <form @submit.prevent="submeterFeriado">
    <div class="backgroundAdmin">
      <div class="adminsubmit">
        <h1>Admin</h1>
        <h2>Adicionar feriado</h2>
        <div class="inputs">
          <div class="feriado">
            <label>Feriado:</label>
            <input class="iinput" type="text" v-model="novoFeriado.feriado">
          </div>
          <div class="dia">
            <label>Dia:</label>
            <input class="iinput" type="text" v-model="novoFeriado.dia">
          </div>
          <v-btn class="botao" outlined color="pink" @click="submeterFeriado()">Submit</v-btn>
        </div>
      </div>
    </div>
  </form>
</template>

<script>
import axios from 'axios';
export default {
  data () {
    return {
      novoFeriado: {
      feriado: '',
      dia: ''
      }
    }
  },
  methods: {
    submeterFeriado(){
      return axios.post('https://apiprodutos-60469-default-rtdb.europe-west1.firebasedatabase.app/data.json', this.novoFeriado);
    }
  }
};
</script>

<style scoped lang="scss">
 .backgroundAdmin {
   display: flex;
   flex-direction: column;
   align-items: center;
 }
 h1{
   padding-bottom: 50px;
 }
 .iinput {
   border: solid 2px black;
   margin-left: 5px;
 }
 .adminsubmit {
   display: flex;
   flex-direction: column;
   align-items: center;
   padding: 10px;
 }
 .feriado {
   width: 250px;
   padding: 8px;
   display: flex;
   justify-content: space-between;
   align-items: center;
 }
 .dia {
   padding: 8px;
   width: 250px;
   display: flex;
   justify-content: space-between;
   align-items: center;
 }
 .inputs{
   display: flex;
   flex-direction: column;
   align-items: flex-end;
   margin-top: 10px;
 }
 .botao {
   margin-top: 10px;
   margin-right: 8px;
 }
</style>
